package dz.example.ecole_primaire2;

import android.animation.ObjectAnimator;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.animation.AccelerateDecelerateInterpolator;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;

public class LoginActivity extends AppCompatActivity {

    private CardView parentCard, teacherCard;
    private LinearLayout loginForm;
    private EditText emailEditText, passwordEditText;
    private Button loginButton;
    private TextView selectedProfileText;
    private ImageView parentIcon, teacherIcon;
    private String selectedProfile = "";

    private static final String PARENT_EMAIL = "ghorabsalama2@gmail.com";
    private static final String PARENT_PASSWORD = "salama";

    private static final String TEACHER_EMAIL = "prof@gmail.com";
    private static final String TEACHER_PASSWORD = "ghorab";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        initViews();
        setupClickListeners();
    }

    private void initViews() {
        parentCard = findViewById(R.id.parentCard);
        teacherCard = findViewById(R.id.teacherCard);
        loginForm = findViewById(R.id.loginForm);
        emailEditText = findViewById(R.id.emailEditText);
        passwordEditText = findViewById(R.id.passwordEditText);
        loginButton = findViewById(R.id.loginButton);
        selectedProfileText = findViewById(R.id.selectedProfileText);
        parentIcon = findViewById(R.id.parentIcon);
        teacherIcon = findViewById(R.id.teacherIcon);
    }

    private void setupClickListeners() {
        parentCard.setOnClickListener(v -> selectProfile("Parent", parentCard, teacherCard));
        teacherCard.setOnClickListener(v -> selectProfile("Enseignant", teacherCard, parentCard));

        loginButton.setOnClickListener(v -> performLogin());
    }

    private void selectProfile(String profile, CardView selectedCard, CardView unselectedCard) {
        selectedProfile = profile;
        selectedProfileText.setText("Profil sélectionné: " + profile);
        selectedProfileText.setVisibility(View.VISIBLE);

        animateCardSelection(selectedCard, true);
        animateCardSelection(unselectedCard, false);

        if (loginForm.getVisibility() == View.GONE) {
            loginForm.setVisibility(View.VISIBLE);
            ObjectAnimator fadeIn = ObjectAnimator.ofFloat(loginForm, "alpha", 0f, 1f);
            fadeIn.setDuration(300);
            fadeIn.start();
        }
    }

    private void animateCardSelection(CardView card, boolean selected) {
        float scaleValue = selected ? 1.05f : 1.0f;
        float elevationValue = selected ? 12f : 4f;

        ObjectAnimator scaleX = ObjectAnimator.ofFloat(card, "scaleX", scaleValue);
        ObjectAnimator scaleY = ObjectAnimator.ofFloat(card, "scaleY", scaleValue);
        ObjectAnimator elevation = ObjectAnimator.ofFloat(card, "cardElevation", elevationValue);

        scaleX.setDuration(200);
        scaleY.setDuration(200);
        elevation.setDuration(200);

        scaleX.setInterpolator(new AccelerateDecelerateInterpolator());
        scaleY.setInterpolator(new AccelerateDecelerateInterpolator());

        scaleX.start();
        scaleY.start();
        elevation.start();

        if (selected) {
            card.setCardBackgroundColor(getResources().getColor(android.R.color.holo_blue_light));
        } else {
            card.setCardBackgroundColor(getResources().getColor(android.R.color.white));
        }
    }

    private void performLogin() {
        String email = emailEditText.getText().toString().trim();
        String password = passwordEditText.getText().toString().trim();

        if (selectedProfile.isEmpty()) {
            Toast.makeText(this, "Veuillez sélectionner un profil", Toast.LENGTH_SHORT).show();
            return;
        }

        if (email.isEmpty()) {
            emailEditText.setError("Email requis");
            return;
        }

        if (password.isEmpty()) {
            passwordEditText.setError("Mot de passe requis");
            return;
        }

        if (!isValidEmail(email)) {
            emailEditText.setError("Format d'email invalide");
            return;
        }

        animateLoginButton();

        if (selectedProfile.equals("Parent")) {
            if (email.equals(PARENT_EMAIL) && password.equals(PARENT_PASSWORD)) {
                Toast.makeText(this, "Connexion réussie! Bienvenue Parent", Toast.LENGTH_SHORT).show();
                Intent intent = new Intent(LoginActivity.this, Parent.class);
                startActivity(intent);

                finish();

            } else {
                Toast.makeText(this, "Email ou mot de passe incorrect pour le profil Parent",
                        Toast.LENGTH_LONG).show();
            }
        }
        else if (selectedProfile.equals("Enseignant")) {
            if (email.equals(TEACHER_EMAIL) && password.equals(TEACHER_PASSWORD)) {
                Toast.makeText(this, "Connexion réussie! Bienvenue Enseignant", Toast.LENGTH_SHORT).show();

                 Intent intent = new Intent(LoginActivity.this, Enseignant.class);
                 startActivity(intent);
                 finish();

            } else {
                Toast.makeText(this, "Email ou mot de passe incorrect pour le profil Enseignant",
                        Toast.LENGTH_LONG).show();
            }
        }
    }

    private void animateLoginButton() {
        ObjectAnimator scaleDown = ObjectAnimator.ofFloat(loginButton, "scaleX", 0.95f);
        ObjectAnimator scaleDownY = ObjectAnimator.ofFloat(loginButton, "scaleY", 0.95f);
        scaleDown.setDuration(100);
        scaleDownY.setDuration(100);

        scaleDown.start();
        scaleDownY.start();

        scaleDown.addListener(new android.animation.AnimatorListenerAdapter() {
            @Override
            public void onAnimationEnd(android.animation.Animator animation) {
                ObjectAnimator scaleUp = ObjectAnimator.ofFloat(loginButton, "scaleX", 1f);
                ObjectAnimator scaleUpY = ObjectAnimator.ofFloat(loginButton, "scaleY", 1f);
                scaleUp.setDuration(100);
                scaleUpY.setDuration(100);
                scaleUp.start();
                scaleUpY.start();
            }
        });
    }

    private boolean isValidEmail(String email) {
        return android.util.Patterns.EMAIL_ADDRESS.matcher(email).matches();
    }
}