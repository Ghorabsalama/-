package dz.example.ecole_primaire2;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import java.text.DecimalFormat;
import java.util.HashMap;


public class arabic1 extends AppCompatActivity {

    private HashMap<String, EditText> reponsesMap = new HashMap<>();
    private double noteFinale = 0;
    private final double pointsFhm = 2.5;
    private final double pointsLng = 3.5;
    private TextView noteFinaleView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);


        ScrollView scrollView = new ScrollView(this);
        LinearLayout mainLayout = new LinearLayout(this);
        mainLayout.setOrientation(LinearLayout.VERTICAL);
        mainLayout.setPadding(16, 16, 16, 16);

        TextView titleText = new TextView(this);
        titleText.setText("اختبار الفصل الأول في مادة اللغة العربية");
        titleText.setTextSize(20);
        titleText.setTextAlignment(View.TEXT_ALIGNMENT_CENTER);
        titleText.setPadding(0, 0, 0, 20);
        mainLayout.addView(titleText);

        TextView sujetText = new TextView(this);
        sujetText.setText(getTexteSupport());
        sujetText.setTextSize(16);
        sujetText.setPadding(0, 0, 0, 20);
        mainLayout.addView(sujetText);

        TextView compTitle = new TextView(this);
        compTitle.setText("أسئلة الفهم (2.5 نقطة):");
        compTitle.setTextSize(18);
        compTitle.setPadding(0, 20, 0, 10);
        mainLayout.addView(compTitle);

        ajouterQuestion(mainLayout, "comp1", "1- هات عنوان مناسب للنص.");
        ajouterQuestion(mainLayout, "comp2", "2- أين تظهر المحبة الصادقة للوطن؟");
        ajouterQuestion(mainLayout, "comp3", "3- استخرج من النص مرادف كلمة: المودة، ووظفها في جملة من إنشائك.");
        ajouterQuestion(mainLayout, "comp4", "4- استخرج من النص ضد كلمة: تنفع، ووظفها في جملة من إنشائك.");

        TextView langTitle = new TextView(this);
        langTitle.setText("أسئلة اللغة (3.5 نقطة):");
        langTitle.setTextSize(18);
        langTitle.setPadding(0, 20, 0, 10);
        mainLayout.addView(langTitle);


        ajouterQuestion(mainLayout, "lang1", "1- أعرب ما تحته خط في النَّص.");
        ajouterQuestion(mainLayout, "lang2", "2- استخرج من النَّص: حرف جر، فعل مضارع، جمع مذكر سالم، نــــــــــــاسخ");
        ajouterQuestion(mainLayout, "lang3", "3- حوِل الجملة التي بين قوسين في النص إلى المفرد المذكر: (إنَّ الْموَاطنينَ الصَّالحينَ مُحبُّونَ لوَطَنهم.)");
        ajouterQuestion(mainLayout, "lang4", "4- علل سبب رسم الهمزة في كلمة \"إخلاص\".");
        ajouterQuestion(mainLayout, "lang5", "5- علل كتابة التاء في كلمة \"المحبة\".");


        Button btnCorrection = new Button(this);
        btnCorrection.setText("تصحيح الاختبار");
        btnCorrection.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                corrigerExamen();
            }
        });
        mainLayout.addView(btnCorrection);

        noteFinaleView = new TextView(this);
        noteFinaleView.setTextSize(18);
        noteFinaleView.setPadding(0, 20, 0, 10);
        mainLayout.addView(noteFinaleView);

        scrollView.addView(mainLayout);
        setContentView(scrollView);
    }

    private void ajouterQuestion(LinearLayout layout, String id, String question) {
        TextView questionText = new TextView(this);
        questionText.setText(question);
        questionText.setTextSize(16);
        questionText.setPadding(0, 10, 0, 5);
        layout.addView(questionText);


        EditText reponseEdit = new EditText(this);
        reponseEdit.setHint("أدخل إجابتك هنا");
        reponseEdit.setMinLines(2);
        reponseEdit.setMaxLines(4);
        layout.addView(reponseEdit);


        reponsesMap.put(id, reponseEdit);
    }

    private void corrigerExamen() {
        noteFinale = 0;
        double noteComprehension = corrigerComprehension();
        double noteLangue = corrigerLangue();

        noteFinale = noteComprehension + noteLangue;

        DecimalFormat df = new DecimalFormat("#.#");
        String noteFormatee = df.format(noteFinale);


        noteFinaleView.setText("النتيجة النهائية: " + noteFormatee + " / 6");

        String message;
        if (noteFinale >= 5) {
            message = "ممتاز! استمر على هذا المستوى";
        } else if (noteFinale >= 3) {
            message = "جيد! واصل المجهود";
        } else {
            message = "تحتاج إلى مزيد من التركيز والمراجعة";
        }

        Toast.makeText(this, message, Toast.LENGTH_LONG).show();
    }

    private double corrigerComprehension() {
        double points = 0;

        String reponseComp1 = reponsesMap.get("comp1").getText().toString().trim();
        if (reponseComp1.contains("المحبة") ||
                reponseComp1.contains("حب الوطن") ||
                reponseComp1.contains("محبة الوطن") ||
                reponseComp1.contains("الوطن")) {
            points += pointsFhm / 4;
        }

        String reponseComp2 = reponsesMap.get("comp2").getText().toString().trim();
        if (reponseComp2.contains("الإخلاص") &&
                reponseComp2.contains("الاجتهاد في العمل")) {
            points += pointsFhm / 4;
        }

        String reponseComp3 = reponsesMap.get("comp3").getText().toString().trim();
        if (reponseComp3.contains("المحبة") && reponseComp3.length() > 10) {
            points += pointsFhm / 4;
        }

        String reponseComp4 = reponsesMap.get("comp4").getText().toString().trim();
        if (reponseComp4.contains("تضر") && reponseComp4.length() > 10) {
            points += pointsFhm / 4;
        }

        return points;
    }

    private double corrigerLangue() {
        double points = 0;

        String reponseLang1 = reponsesMap.get("lang1").getText().toString().trim();
        if (reponseLang1.contains("إنّ") && reponseLang1.contains("ناسخ") ||
                reponseLang1.contains("حرف توكيد ونصب") ||
                reponseLang1.contains("مبتدأ مرفوع") ||
                reponseLang1.contains("خبر منصوب")) {
            points += pointsLng / 5;
        }

        String reponseLang2 = reponsesMap.get("lang2").getText().toString().trim();
        boolean hasPrep = reponseLang2.contains("في") || reponseLang2.contains("على") || reponseLang2.contains("من") || reponseLang2.contains("لـ");
        boolean hasVerb = reponseLang2.contains("يظهر") || reponseLang2.contains("تظهر") || reponseLang2.contains("تكون") || reponseLang2.contains("يحبون");
        boolean hasPlural = reponseLang2.contains("المواطنين") || reponseLang2.contains("الصالحين") || reponseLang2.contains("محبون");
        boolean hasNasikh = reponseLang2.contains("إن") || reponseLang2.contains("كان") || reponseLang2.contains("أن");

        if (hasPrep && hasVerb && hasPlural && hasNasikh) {
            points += pointsLng / 5;
        }

        String reponseLang3 = reponsesMap.get("lang3").getText().toString().trim();
        if (reponseLang3.contains("إن المواطن الصالح محب لوطنه") ||
                reponseLang3.contains("إنّ المواطن الصالح محبٌ لوطنه")) {
            points += pointsLng / 5;
        }

        String reponseLang4 = reponsesMap.get("lang4").getText().toString().trim();
        if (reponseLang4.contains("همزة قطع") ||
                reponseLang4.contains("في بداية الكلمة") ||
                reponseLang4.contains("لأنها همزة قطع في بداية الاسم")) {
            points += pointsLng / 5;
        }

        String reponseLang5 = reponsesMap.get("lang5").getText().toString().trim();
        if (reponseLang5.contains("تاء مربوطة") ||
                reponseLang5.contains("اسم مؤنث") ||
                reponseLang5.contains("تاء التأنيث")) {
            points += pointsLng / 5;
        }

        return points;
    }

    private String getTexteSupport() {
        return "السند:\n" +
                "الْمَحَبَّةُ\n" +
                "الْمَحَبَّةُ الصَّادِقَةُ لِلْوَطَنِ تَظْهَرُ فِي الْإِخْلَاصِ وَالْاِجْتِهَادِ فِي الْعَمَلِ، فَالْإِخْلَاصُ أَنْ تَعْمَلَ لِوَطَنِكَ لَوْ أَنْكَرَكَ وَ أَنْكَرَ عَمَلَكَ أَبْنَاءُ وَطَنِكَ، وَ إِتْقَانُ الْعَمَلِ أَنْ تَكُونَ جَمِيع أَعْمَالِكَ تَامَّةَ غَيْرِ نَاقِصَةٍ وَعَائِدَة بِالْخَيْرِ عَلَى وَطَنِكَ، فَتَسْتَطِيعُ أَنْ تَنْفَعَ النَّاسَ كُلَّهُمْ دُونَ أَنْ تَضُرَّ بِوَطَنِكَ فَتَكُون قَدْ خَدمتهُ بِمَا زَرَعَتْ لَهُ مِنْ مَحَبَّة فِي قَلُوب مَنْ أَحْسَنَتْ إِلَيْهِمْ.\n" +
                "(إنَّ الْموَاطنينَ الصَّالحينَ مُحبُّونَ لوَطَنهم)، وَلَا يَكْرَهُونَ الْعَيْشَ فِيهِ وَيَعْمَلُونَ عَلَى اِزْدِهَارِهِ وَيُدَافِعُونَ عَنْهُ بِمَا يَمْلِكُونَ، لِأَنَّ الَّذِينَ يُحِبُّونَ وطنهم هُمْ مَنْ يَبْذُلُونَ جُهْدَهُمْ فِيمَا يَرْفَعُونَ شَأْنَهُ بَيْنَ الْأُمَمِ.\n" +
                "اِجْتَهَد أَن تَكونَ مَصْدَرَ مَحَبَّةِ شَامِلَةِ وَنَفْعِ عَام. أَحِبْ وَطَنَكَ وَلَا تَكْرَه أَوطَان النَّاسِ، اِنْفَعْ وَطَنَكَ وَلَا تَضُرْ أَوطَانًا أُخْرَى.";
    }
}