package dz.example.ecole_primaire2;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;


public class english extends AppCompatActivity {

    private RadioGroup question1Group;
    private RadioButton rbDoll, rbBall, rbKite, rbTrain;

    private CheckBox cbGreenCarYes, cbGreenCarNo;
    private CheckBox cbBlueBearYes, cbBlueBearNo;

    private RadioGroup question3aGroup, question3bGroup;
    private RadioButton rbQ3aA, rbQ3aB, rbQ3bA, rbQ3bB;

    private EditText etThreeBalls, etOneBike;

    private EditText etGarden, etComputer, etBlack;

    private Button btnSubmit, btnReset;
    private TextView tvResults;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.english);

        initializeViews();
        setupEventListeners();
    }

    private void initializeViews() {
        question1Group = findViewById(R.id.question1_group);
        rbDoll = findViewById(R.id.rb_doll);
        rbBall = findViewById(R.id.rb_ball);
        rbKite = findViewById(R.id.rb_kite);
        rbTrain = findViewById(R.id.rb_train);

        cbGreenCarYes = findViewById(R.id.cb_green_car_yes);
        cbGreenCarNo = findViewById(R.id.cb_green_car_no);
        cbBlueBearYes = findViewById(R.id.cb_blue_bear_yes);
        cbBlueBearNo = findViewById(R.id.cb_blue_bear_no);

        question3aGroup = findViewById(R.id.question3a_group);
        question3bGroup = findViewById(R.id.question3b_group);
        rbQ3aA = findViewById(R.id.rb_q3a_a);
        rbQ3aB = findViewById(R.id.rb_q3a_b);
        rbQ3bA = findViewById(R.id.rb_q3b_a);
        rbQ3bB = findViewById(R.id.rb_q3b_b);

        etThreeBalls = findViewById(R.id.et_three_balls);
        etOneBike = findViewById(R.id.et_one_bike);

        etGarden = findViewById(R.id.et_garden);
        etComputer = findViewById(R.id.et_computer);
        etBlack = findViewById(R.id.et_black);

        btnSubmit = findViewById(R.id.btn_submit);
        btnReset = findViewById(R.id.btn_reset);
        tvResults = findViewById(R.id.tv_results);
    }

    private void setupEventListeners() {
        btnSubmit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                checkAnswers();
            }
        });

        btnReset.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                resetExam();
            }
        });

        cbGreenCarYes.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (cbGreenCarYes.isChecked()) {
                    cbGreenCarNo.setChecked(false);
                }
            }
        });

        cbGreenCarNo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (cbGreenCarNo.isChecked()) {
                    cbGreenCarYes.setChecked(false);
                }
            }
        });

        cbBlueBearYes.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (cbBlueBearYes.isChecked()) {
                    cbBlueBearNo.setChecked(false);
                }
            }
        });

        cbBlueBearNo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (cbBlueBearNo.isChecked()) {
                    cbBlueBearYes.setChecked(false);
                }
            }
        });
    }

    private void checkAnswers() {
        int score = 0;
        int totalQuestions = 8; // Total des sous-questions
        StringBuilder results = new StringBuilder();
        results.append("Résultats de l'examen:\n\n");

        if (rbDoll.isChecked()) {
            results.append("Q1: Correct! (Robot/Doll) ✓\n");
            score++;
        } else {
            results.append("Q1: Incorrect. La bonne réponse est Robot/Doll ✗\n");
        }

        if (cbGreenCarYes.isChecked()) {
            results.append("Q2a: Correct! (Yes, it is) ✓\n");
            score++;
        } else {
            results.append("Q2a: Incorrect. La bonne réponse est 'Yes, it is' ✗\n");
        }

        if (cbBlueBearNo.isChecked()) {
            results.append("Q2b: Correct! (No, it is not) ✓\n");
            score++;
        } else {
            results.append("Q2b: Incorrect. La bonne réponse est 'No, it is not' ✗\n");
        }

        if (rbQ3bB.isChecked()) {
            results.append("Q3a: Correct! ✓\n");
            score++;
        } else {
            results.append("Q3a: Incorrect ✗\n");
        }

        if (rbQ3aA.isChecked()) {
            results.append("Q3b: Correct! ✓\n");
            score++;
        } else {
            results.append("Q3b: Incorrect ✗\n");
        }

        String threeBallsAnswer = etThreeBalls.getText().toString().trim().toLowerCase();
        if (threeBallsAnswer.equals("three") || threeBallsAnswer.equals("3")) {
            results.append("Q4a: Correct! (three) ✓\n");
            score++;
        } else {
            results.append("Q4a: Incorrect. La bonne réponse est 'three' ✗\n");
        }

        String oneBikeAnswer = etOneBike.getText().toString().trim().toLowerCase();
        if (oneBikeAnswer.equals("one") || oneBikeAnswer.equals("1")) {
            results.append("Q4b: Correct! (one) ✓\n");
            score++;
        } else {
            results.append("Q4b: Incorrect. La bonne réponse est 'one' ✗\n");
        }

        String gardenAnswer = etGarden.getText().toString().trim().toLowerCase();
        String computerAnswer = etComputer.getText().toString().trim().toLowerCase();
        String blackAnswer = etBlack.getText().toString().trim().toLowerCase();

        if (gardenAnswer.equals("g")) {
            results.append("Q5a: Correct! (g - garden) ✓\n");
            score++;
        } else {
            results.append("Q5a: Incorrect. La lettre manquante est 'g' ✗\n");
        }


        double percentage = (double) score / totalQuestions * 100;
        results.append(String.format("\nScore final: %d/%d (%.1f%%)", score, totalQuestions, percentage));

        if (percentage >= 80) {
            results.append("\nExcellent travail! 🌟");
        } else if (percentage >= 60) {
            results.append("\nBon travail! 👍");
        } else {
            results.append("\nContinue à t'entraîner! 💪");
        }

        tvResults.setText(results.toString());
        tvResults.setVisibility(View.VISIBLE);

        Toast.makeText(this, String.format("Score: %d/%d", score, totalQuestions),
                Toast.LENGTH_LONG).show();
    }

    private void resetExam() {
        question1Group.clearCheck();

        cbGreenCarYes.setChecked(false);
        cbGreenCarNo.setChecked(false);
        cbBlueBearYes.setChecked(false);
        cbBlueBearNo.setChecked(false);

        question3aGroup.clearCheck();
        question3bGroup.clearCheck();

        etThreeBalls.setText("");
        etOneBike.setText("");

        etGarden.setText("");
        etComputer.setText("");
        etBlack.setText("");

        tvResults.setVisibility(View.GONE);

        Toast.makeText(this, "Examen réinitialisé", Toast.LENGTH_SHORT).show();
    }

    public String getQuestion1Answer() {
        if (rbDoll.isChecked()) return "Doll";
        if (rbBall.isChecked()) return "Ball";
        if (rbKite.isChecked()) return "Kite";
        if (rbTrain.isChecked()) return "Train";
        return "Non répondu";
    }

    public boolean isGreenCarCorrect() {
        return cbGreenCarYes.isChecked();
    }

    public boolean isBlueBearCorrect() {
        return cbBlueBearNo.isChecked();
    }

    public String getThreeBallsAnswer() {
        return etThreeBalls.getText().toString().trim();
    }

    public String getOneBikeAnswer() {
        return etOneBike.getText().toString().trim();
    }

    public String getGardenAnswer() {
        return etGarden.getText().toString().trim();
    }

    public String getComputerAnswer() {
        return etComputer.getText().toString().trim();
    }

    public String getBlackAnswer() {
        return etBlack.getText().toString().trim();
    }
}