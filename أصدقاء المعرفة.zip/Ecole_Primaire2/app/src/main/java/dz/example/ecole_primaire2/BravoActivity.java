package dz.example.ecole_primaire2;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.view.animation.RotateAnimation;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import java.util.Random;
import java.util.ArrayList;
import java.util.List;

public class BravoActivity extends AppCompatActivity {

    private TextView tvTitle, tvSubtitle, tvMessage;
    private Button btnRetour;
    private LinearLayout confettiContainer;
    private RelativeLayout mainLayout;
    private Random random = new Random();
    private List<ImageView> animatedIcons = new ArrayList<>();

    private int[] celebrationIcons = {
            android.R.drawable.btn_star_big_on,
            android.R.drawable.btn_star_big_off,
            R.drawable.hero,
            R.drawable.bravoo,
            R.drawable.medal,
            R.drawable.diamond,
            R.drawable.award,
            R.drawable.star,
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_bravo);

        initViews();

        setupAnimations();

        createRandomAnimatedIcons();

        setupReturnButton();
    }

    private void initViews() {
        tvTitle = findViewById(R.id.tv_title);
        tvSubtitle = findViewById(R.id.tv_subtitle);
        tvMessage = findViewById(R.id.tv_message);
        btnRetour = findViewById(R.id.btn_retour);
        confettiContainer = findViewById(R.id.confetti_container);
        mainLayout = findViewById(R.id.main_layout); // Le RelativeLayout principal
    }

    private void setupAnimations() {
        Animation fadeIn = AnimationUtils.loadAnimation(this, android.R.anim.fade_in);

        Animation titleAnimation = AnimationUtils.loadAnimation(this, android.R.anim.slide_in_left);
        titleAnimation.setDuration(800);
        tvTitle.startAnimation(titleAnimation);

        tvSubtitle.postDelayed(new Runnable() {
            @Override
            public void run() {
                Animation subtitleAnimation = AnimationUtils.loadAnimation(BravoActivity.this, android.R.anim.slide_in_left);
                subtitleAnimation.setDuration(600);
                tvSubtitle.startAnimation(subtitleAnimation);
            }
        }, 300);

        tvMessage.postDelayed(new Runnable() {
            @Override
            public void run() {
                tvMessage.startAnimation(fadeIn);
            }
        }, 600);

        btnRetour.postDelayed(new Runnable() {
            @Override
            public void run() {
                Animation buttonAnimation = AnimationUtils.loadAnimation(BravoActivity.this, android.R.anim.slide_in_left);
                buttonAnimation.setDuration(500);
                btnRetour.startAnimation(buttonAnimation);
            }
        }, 900);

        animateConfetti();
    }

    private void createRandomAnimatedIcons() {
        int screenWidth = getResources().getDisplayMetrics().widthPixels;
        int screenHeight = getResources().getDisplayMetrics().heightPixels;

        int numberOfIcons = 12 + random.nextInt(7); // Entre 12 et 18 icônes

        for (int i = 0; i < numberOfIcons; i++) {
            createSingleRandomIcon(screenWidth, screenHeight, i * 150);
        }
    }

    private void createSingleRandomIcon(int screenWidth, int screenHeight, int delay) {
        ImageView iconView = new ImageView(this);

        int randomIcon = celebrationIcons[random.nextInt(celebrationIcons.length)];
        iconView.setImageResource(randomIcon);

        int iconSize = dpToPx(32 + random.nextInt(33)); // 32-64dp
        RelativeLayout.LayoutParams params = new RelativeLayout.LayoutParams(iconSize, iconSize);

        int x = random.nextInt(Math.max(1, screenWidth - iconSize));
        int y = random.nextInt(Math.max(1, screenHeight - iconSize));

        int centerX = screenWidth / 2;
        int centerY = screenHeight / 2;
        int avoidZone = dpToPx(150); // Zone à éviter autour du centre

        if (Math.abs(x - centerX) < avoidZone && Math.abs(y - centerY) < avoidZone) {
            // Si dans la zone centrale, déplacer vers les bords
            if (x < centerX) {
                x = Math.max(0, centerX - avoidZone - iconSize);
            } else {
                x = Math.min(screenWidth - iconSize, centerX + avoidZone);
            }
        }

        params.leftMargin = x;
        params.topMargin = y;
        iconView.setLayoutParams(params);

        float alpha = 0.3f + random.nextFloat() * 0.5f; // Entre 0.3 et 0.8
        iconView.setAlpha(alpha);

        animatedIcons.add(iconView);

        mainLayout.addView(iconView);

        iconView.postDelayed(new Runnable() {
            @Override
            public void run() {
                startRandomIconAnimation(iconView);
            }
        }, delay);
    }

    private void startRandomIconAnimation(ImageView iconView) {
        RotateAnimation rotateAnimation = new RotateAnimation(
                0f, 360f,
                Animation.RELATIVE_TO_SELF, 0.5f,
                Animation.RELATIVE_TO_SELF, 0.5f
        );

        int duration = 2000 + random.nextInt(4000);
        rotateAnimation.setDuration(duration);
        rotateAnimation.setRepeatCount(Animation.INFINITE);
        rotateAnimation.setRepeatMode(Animation.RESTART);

        iconView.startAnimation(rotateAnimation);

        iconView.animate()
                .scaleX(1.2f)
                .scaleY(1.2f)
                .setDuration(1500 + random.nextInt(1000))
                .withEndAction(new Runnable() {
                    @Override
                    public void run() {
                        iconView.animate()
                                .scaleX(0.8f)
                                .scaleY(0.8f)
                                .setDuration(1500 + random.nextInt(1000))
                                .withEndAction(new Runnable() {
                                    @Override
                                    public void run() {
                                        startScaleAnimation(iconView);
                                    }
                                })
                                .start();
                    }
                })
                .start();
    }

    private void startScaleAnimation(ImageView iconView) {
        iconView.animate()
                .scaleX(1.2f)
                .scaleY(1.2f)
                .setDuration(1500 + random.nextInt(1000))
                .withEndAction(new Runnable() {
                    @Override
                    public void run() {
                        iconView.animate()
                                .scaleX(0.8f)
                                .scaleY(0.8f)
                                .setDuration(1500 + random.nextInt(1000))
                                .withEndAction(new Runnable() {
                                    @Override
                                    public void run() {
                                        startScaleAnimation(iconView);
                                    }
                                })
                                .start();
                    }
                })
                .start();
    }

    private int dpToPx(int dp) {
        return (int) (dp * getResources().getDisplayMetrics().density);
    }

    private void animateConfetti() {
        confettiContainer.removeAllViews();

        for (int i = 0; i < 5; i++) {
            ImageView confettiIcon = new ImageView(this);
            int randomIcon = celebrationIcons[random.nextInt(celebrationIcons.length)];
            confettiIcon.setImageResource(randomIcon);

            // Paramètres pour le LinearLayout
            LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(
                    dpToPx(32), dpToPx(32)
            );
            params.setMargins(dpToPx(8), dpToPx(4), dpToPx(8), dpToPx(4));
            confettiIcon.setLayoutParams(params);
            confettiIcon.setAlpha(0.7f + random.nextFloat() * 0.3f);

            confettiContainer.addView(confettiIcon);
            animatedIcons.add(confettiIcon);
        }

        for (int i = 0; i < confettiContainer.getChildCount(); i++) {
            final View confetti = confettiContainer.getChildAt(i);

            confetti.postDelayed(new Runnable() {
                @Override
                public void run() {
                    confetti.animate()
                            .rotationBy(360f)
                            .setDuration(2000)
                            .withEndAction(new Runnable() {
                                @Override
                                public void run() {
                                    // Répéter l'animation
                                    animateSingleConfetti(confetti);
                                }
                            })
                            .start();
                }
            }, i * 200); // Délai progressif pour chaque confetti
        }
    }

    private void animateSingleConfetti(View confetti) {
        confetti.animate()
                .rotationBy(360f)
                .setDuration(2000)
                .withEndAction(new Runnable() {
                    @Override
                    public void run() {
                        animateSingleConfetti(confetti); // Boucle pour l'animation continue
                    }
                })
                .start();
    }

    private void setupReturnButton() {
        btnRetour.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                v.animate()
                        .scaleX(0.9f)
                        .scaleY(0.9f)
                        .setDuration(100)
                        .withEndAction(new Runnable() {
                            @Override
                            public void run() {
                                v.animate()
                                        .scaleX(1f)
                                        .scaleY(1f)
                                        .setDuration(100)
                                        .withEndAction(new Runnable() {
                                            @Override
                                            public void run() {
                                                retourMainActivity();
                                            }
                                        })
                                        .start();
                            }
                        })
                        .start();
            }
        });
    }

    private void retourMainActivity() {
        Intent intent = new Intent(BravoActivity.this, MainActivity.class);

        intent.putExtra("reponse_correcte", true);
        intent.putExtra("message", "Bonne réponse donnée !");

        intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_NEW_TASK);

        startActivity(intent);
        overridePendingTransition(android.R.anim.slide_in_left, android.R.anim.slide_out_right);
        finish();
    }

    @Override
    public void onBackPressed() {
        retourMainActivity();
        super.onBackPressed();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (tvTitle != null) tvTitle.clearAnimation();
        if (tvSubtitle != null) tvSubtitle.clearAnimation();
        if (tvMessage != null) tvMessage.clearAnimation();
        if (btnRetour != null) btnRetour.clearAnimation();

        if (confettiContainer != null) {
            for (int i = 0; i < confettiContainer.getChildCount(); i++) {
                View confetti = confettiContainer.getChildAt(i);
                if (confetti != null) {
                    confetti.animate().cancel();
                    confetti.clearAnimation();
                }
            }
        }

        for (ImageView icon : animatedIcons) {
            if (icon != null) {
                icon.animate().cancel();
                icon.clearAnimation();
            }
        }
        animatedIcons.clear();
    }
}