package dz.example.ecole_primaire2;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.TextView;
import androidx.cardview.widget.CardView;
import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.GravityCompat;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.drawerlayout.widget.DrawerLayout;

public class MainActivity extends AppCompatActivity {

    private DrawerLayout drawerLayout;
    private ImageButton btnOpenMenu;
    private CardView cardFirstGrade;
    private CardView cardSecondGrade;
    private CardView cardThirdGrade;
    private CardView cardFifthGrade;
    private CardView cardFourthGrade;
    private Button nav_login;
    private ImageButton lectureButton;
    private ImageButton teacherButton;
    private ImageButton quizButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        setupFooterButtons();

        cardFirstGrade = findViewById(R.id.cardFirstGrade);
        cardSecondGrade = findViewById(R.id.cardSecondGrade);
        cardThirdGrade = findViewById(R.id.cardThirdGrade);
        cardFourthGrade = findViewById(R.id.cardFourthGrade);
        cardFifthGrade = findViewById(R.id.cardFifthGrade);
        nav_login = findViewById(R.id.nav_login);

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });


        btnOpenMenu = findViewById(R.id.btnOpenMenu);
        drawerLayout = findViewById(R.id.drawer_layout);

        cardFirstGrade.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, Matieres_1Ap.class);
                startActivity(intent);
            }
        });
        cardSecondGrade.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, Matieres_2Ap.class);
                startActivity(intent);
            }
        });
        cardThirdGrade.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, Matieres_3Ap.class);
                startActivity(intent);
            }
        });

        cardFifthGrade.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, Matieres_5Ap.class);
                startActivity(intent);
            }
        });
        cardFourthGrade.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, Matieres_4Ap.class);
                startActivity(intent);
            }
        });

        btnOpenMenu.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                drawerLayout.openDrawer(GravityCompat.START);
            }
        });

        setupNavigationItemClickListeners();
    }


    private void setupNavigationItemClickListeners() {

        nav_login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, LoginActivity.class);
                startActivity(intent);
            }
        });


        TextView navExams = findViewById(R.id.nav_exams);
        navExams.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                drawerLayout.closeDrawers();
            }
        });

        TextView navGrades = findViewById(R.id.nav_grades);
        navGrades.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                drawerLayout.closeDrawers();
            }
        });

        TextView navMessages = findViewById(R.id.nav_messages);
        navMessages.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                drawerLayout.closeDrawers();
            }
        });

        TextView navHelp = findViewById(R.id.nav_help);
        navHelp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                drawerLayout.closeDrawers();
            }
        });

        View navLogout = findViewById(R.id.nav_logout);
        navLogout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                drawerLayout.closeDrawers();
            }
        });
    }

    private void setupFooterButtons() {

        lectureButton = findViewById(R.id.lectureButton);
        teacherButton = findViewById(R.id.teacherButton);
        quizButton = findViewById(R.id.quizButton);


        lectureButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                    Intent intent = new Intent(MainActivity.this, Lecture.class);
                    startActivity(intent);
            }
        });

        teacherButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, teacher.class);
                startActivity(intent);
            }
        });

        quizButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                   Intent intent = new Intent(MainActivity.this, quiz.class);
                   startActivity(intent);
            }
        });
    }
}