package dz.example.ecole_primaire2;

import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class operations extends AppCompatActivity {

    private EditText et1, et2, et3, et4, et5, et6, et7, et8;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.operation);

        et1 = findViewById(R.id.et1);
        et2 = findViewById(R.id.et2);
        et3 = findViewById(R.id.et3);
        et4 = findViewById(R.id.et4);
        et5 = findViewById(R.id.et5);
        et6 = findViewById(R.id.et6);
        et7 = findViewById(R.id.et7);
        et8 = findViewById(R.id.et8);

        setupTextWatcher(et1, 3);
        setupTextWatcher(et2, 15);
        setupTextWatcher(et3, 10);
        setupTextWatcher(et4, 8);
        setupTextWatcher(et5, 10);
        setupTextWatcher(et6, 2);
        setupTextWatcher(et7, 4);
        setupTextWatcher(et8, 6);
    }

    private void setupTextWatcher(EditText editText, int correctAnswer) {
        editText.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {}

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {}

            @Override
            public void afterTextChanged(Editable s) {
                String input = s.toString().trim();
                if (!input.isEmpty()) {

                        int userAnswer = Integer.parseInt(input);
                        if (userAnswer == correctAnswer) {
                            Toast.makeText(operations.this, "جواب صحيح", Toast.LENGTH_SHORT).show();
                        }
                                    }
            }
        });
    }
}