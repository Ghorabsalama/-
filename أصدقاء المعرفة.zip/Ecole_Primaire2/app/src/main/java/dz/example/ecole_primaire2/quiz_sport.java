package dz.example.ecole_primaire2;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.DialogInterface;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.RadioGroup;
import android.widget.Toast;

public class quiz_sport extends AppCompatActivity {

    private RadioGroup radioGroup1, radioGroup2, radioGroup3;
    private Button buttonSubmit;
    private int score = 0;
    private boolean quizSubmitted = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.quiz_sport);

        radioGroup1 = findViewById(R.id.radioGroup1);
        radioGroup2 = findViewById(R.id.radioGroup2);
        radioGroup3 = findViewById(R.id.radioGroup3);
        buttonSubmit = findViewById(R.id.buttonSubmit);

        buttonSubmit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (quizSubmitted) {
                    finish();
                    return;
                }

                if (radioGroup1.getCheckedRadioButtonId() == -1 ||
                        radioGroup2.getCheckedRadioButtonId() == -1 ||
                        radioGroup3.getCheckedRadioButtonId() == -1) {
                    Toast.makeText(quiz_sport.this, "Please answer all questions!", Toast.LENGTH_SHORT).show();
                    return;
                }

                calculateScore();

                showResult();

                buttonSubmit.setText("Return to Main Menu");
                quizSubmitted = true;
            }
        });
    }

    private void calculateScore() {
        score = 0;

        if (radioGroup1.getCheckedRadioButtonId() == R.id.radioQ1A3) {
            score++;
        }

        if (radioGroup2.getCheckedRadioButtonId() == R.id.radioQ2A2) {
            score++;
        }

        if (radioGroup3.getCheckedRadioButtonId() == R.id.radioQ3A4) {
            score++;
        }
    }

    private void showResult() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Quiz Result");

        String message = "Your score: " + score + " out of 3\n\n";

        message += "Question 1: Brazil\n";
        message += "Question 2: 5\n";
        message += "Question 3: Both Tennis and Badminton\n\n";

        if (score == 3) {
            message += "Excellent! Perfect score!";
        } else if (score == 2) {
            message += "Good job! Almost perfect!";
        } else if (score == 1) {
            message += "Not bad! Keep learning!";
        } else {
            message += "Try again! You can do better!";
        }

        builder.setMessage(message);
        builder.setPositiveButton("OK", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialog.dismiss();
            }
        });

        AlertDialog dialog = builder.create();
        dialog.show();
    }
}
