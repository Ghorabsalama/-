package dz.example.ecole_primaire2;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import com.android.volley.NetworkResponse;
import com.android.volley.ParseError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.HttpHeaderParser;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.util.HashMap;
import java.util.Map;

public class paragraph_api extends AppCompatActivity {

    private EditText etParagraph;
    private Button btnSubmit;
    private Button btnContinue;
    private TextView tvFeedback;
    private ProgressBar progressBar;
    private RequestQueue requestQueue;

    private static final String API_URL = "https://api.languagetool.org/v2/check";
    private static final String LANGUAGE = "fr";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.paragraph_api);

        initializeViews();
        setupRequestQueue();
        setupButtonListeners();
    }

    private void initializeViews() {
        etParagraph = findViewById(R.id.etParagraph);
        btnSubmit = findViewById(R.id.btnSubmit);
        btnContinue = findViewById(R.id.btnContinue);
        tvFeedback = findViewById(R.id.tvFeedback);
        progressBar = findViewById(R.id.progressBar);
    }

    private void setupRequestQueue() {
        requestQueue = Volley.newRequestQueue(this);
    }

    private void setupButtonListeners() {
        btnSubmit.setOnClickListener(v -> {
            String text = etParagraph.getText().toString().trim();
            if (text.isEmpty()) {
                tvFeedback.setText("Veuillez entrer votre paragraphe à analyser");
                hideContinueButton();
            } else {
                checkGrammar(text);
            }
        });

        btnContinue.setOnClickListener(v -> {
            Intent intent = new Intent(paragraph_api.this, BravoActivity.class);
            startActivity(intent);
        });
    }

    private void checkGrammar(String text) {
        progressBar.setVisibility(View.VISIBLE);
        tvFeedback.setText("");
        hideContinueButton();

        StringRequest request = new StringRequest(
                Request.Method.POST,
                API_URL,
                this::handleApiResponse,
                this::handleApiError
        ) {
            @Override
            public byte[] getBody() {
                try {
                    String postData = "text=" + URLEncoder.encode(text, "UTF-8")
                            + "&language=" + LANGUAGE;
                    return postData.getBytes(StandardCharsets.UTF_8);
                } catch (UnsupportedEncodingException e) {
                    return new byte[0];
                }
            }

            @Override
            protected Response<String> parseNetworkResponse(NetworkResponse response) {
                try {
                    return Response.success(
                            new String(response.data, StandardCharsets.UTF_8),
                            HttpHeaderParser.parseCacheHeaders(response)
                    );
                } catch (Exception e) {
                    return Response.error(new ParseError(e));
                }
            }

            @Override
            public Map<String, String> getHeaders() {
                Map<String, String> headers = new HashMap<>();
                headers.put("Content-Type", "application/x-www-form-urlencoded; charset=UTF-8");
                return headers;
            }
        };

        requestQueue.add(request);
    }

    private void handleApiResponse(String response) {
        runOnUiThread(() -> {
            progressBar.setVisibility(View.GONE);
            try {
                JSONObject jsonResponse = new JSONObject(response);
                processApiResponse(jsonResponse);
            } catch (JSONException e) {
                tvFeedback.setText("Erreur d'analyse de la réponse");
                hideContinueButton();
            }
        });
    }

    private void processApiResponse(JSONObject response) throws JSONException {
        JSONArray matches = response.getJSONArray("matches");
        if (matches.length() == 0) {
            tvFeedback.setText("✔ Aucune erreur trouvée ! Excellent travail !");
            showContinueButton();
            return;
        }
        displayGrammarErrors(matches);
        hideContinueButton();
    }

    private void displayGrammarErrors(JSONArray matches) throws JSONException {
        StringBuilder feedback = new StringBuilder();
        for (int i = 0; i < matches.length(); i++) {
            JSONObject error = matches.getJSONObject(i);
            feedback.append(String.format("⚠ %s → %s\n\n",
                    error.optString("message", "Erreur inconnue"),
                    getBestSuggestion(error.optJSONArray("replacements"))));
        }
        tvFeedback.setText(feedback.toString());
    }

    private String getBestSuggestion(JSONArray replacements) {
        try {
            return (replacements != null && replacements.length() > 0)
                    ? replacements.getJSONObject(0).getString("value")
                    : "Aucune suggestion";
        } catch (JSONException e) {
            return "Erreur dans la suggestion";
        }
    }

    private void handleApiError(VolleyError error) {
        runOnUiThread(() -> {
            progressBar.setVisibility(View.GONE);
            String errorMessage = "Erreur : ";
            try {
                if (error.networkResponse != null) {
                    errorMessage += new String(error.networkResponse.data, StandardCharsets.UTF_8);
                }
            } catch (Exception e) {
                errorMessage += "Problème de connexion";
            }
            tvFeedback.setText(errorMessage);
            hideContinueButton();
        });
    }

    private void showContinueButton() {
        btnContinue.setVisibility(View.VISIBLE);
        btnSubmit.setVisibility(View.GONE);
    }

    private void hideContinueButton() {
        btnContinue.setVisibility(View.GONE);
        btnSubmit.setVisibility(View.VISIBLE);
    }
}