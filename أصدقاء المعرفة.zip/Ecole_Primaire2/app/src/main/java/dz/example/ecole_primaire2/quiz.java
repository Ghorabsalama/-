package dz.example.ecole_primaire2;

import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class quiz extends AppCompatActivity {

    private CardView cardViewSport, cardViewAnimals, cardViewMore;
    private Button btnSportSignUp, btnAnimalsSignUp;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.quiz);

        cardViewSport = findViewById(R.id.cardViewSport);
        cardViewAnimals = findViewById(R.id.cardViewAnimals);
        btnSportSignUp = findViewById(R.id.buttonSportSignUp);
        btnAnimalsSignUp = findViewById(R.id.buttonAnimalsSignUp);

        cardViewSport.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(quiz.this, quiz_sport.class));
            }
        });

        btnSportSignUp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(quiz.this, quiz_sport.class));
            }
        });

        cardViewAnimals.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(quiz.this, quiz_animal.class));
            }
        });

        btnAnimalsSignUp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(quiz.this, quiz_animal.class));
            }
        });

    }
}