package dz.example.ecole_primaire2;

import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;

public class Enseignant extends AppCompatActivity {

    private TextView texteAccueil, nomEnseignantTexte;
    private CardView carteQuiz, carteEleves, carteNotes,
            carteDevoirs, carteMessages, carteRapports;

    private String nomEnseignant;
    private String emailEnseignant;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.enseignant);

        Intent intent = getIntent();
        emailEnseignant = intent.getStringExtra("user_email");
        nomEnseignant = "Prof. " + (emailEnseignant != null ? emailEnseignant.split("@")[0] : "Enseignant");

        initialiserVues();
        configurerEcouteursClics();
        configurerMessageAccueil();
    }

    private void initialiserVues() {
        texteAccueil = findViewById(R.id.welcomeText);
        nomEnseignantTexte = findViewById(R.id.teacherNameText);
        carteQuiz = findViewById(R.id.quizCard);
        carteEleves = findViewById(R.id.studentsCard);
        carteNotes = findViewById(R.id.notesCard);
        carteDevoirs = findViewById(R.id.homeworkCard);
        carteMessages = findViewById(R.id.messagesCard);
        carteRapports = findViewById(R.id.reportsCard);
    }

    private void configurerMessageAccueil() {
        texteAccueil.setText("Bienvenue dans votre espace enseignant");
        nomEnseignantTexte.setText(nomEnseignant);
    }

    private void configurerEcouteursClics() {
        carteQuiz.setOnClickListener(v -> {

        });

        carteEleves.setOnClickListener(v -> {

        });

        carteNotes.setOnClickListener(v -> {

        });

        carteDevoirs.setOnClickListener(v -> {

        });

        carteMessages.setOnClickListener(v -> {

        });

        carteRapports.setOnClickListener(v -> {

        });
    }


}