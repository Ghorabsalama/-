package dz.example.ecole_primaire2;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class his_geo extends AppCompatActivity {

    private EditText etComposant1, etComposant2, etComposant3, etComposant4;
    private RadioGroup rgSurfaceTerre, rgSurfaceAlgerie, rgLittoral, rgFrontieres;
    private CheckBox cbCorrect1, cbCorrect2, cbCorrect3, cbCorrect4;
    private EditText etManifestations;
    private Button btnVerifier, btnAfficherCorrection;
    private TextView tvResultat, tvCorrection;
    private LinearLayout layoutCorrection;

    private int score = 0;
    private int totalQuestions = 12;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.his_geo);

        initializeViews();
        setupListeners();
    }

    private void initializeViews() {
        etComposant1 = findViewById(R.id.et_composant1);
        etComposant2 = findViewById(R.id.et_composant2);
        etComposant3 = findViewById(R.id.et_composant3);
        etComposant4 = findViewById(R.id.et_composant4);

        rgSurfaceTerre = findViewById(R.id.rg_surface_terre);
        rgSurfaceAlgerie = findViewById(R.id.rg_surface_algerie);
        rgLittoral = findViewById(R.id.rg_littoral);
        rgFrontieres = findViewById(R.id.rg_frontieres);

        cbCorrect1 = findViewById(R.id.cb_correct1);
        cbCorrect2 = findViewById(R.id.cb_correct2);
        cbCorrect3 = findViewById(R.id.cb_correct3);
        cbCorrect4 = findViewById(R.id.cb_correct4);

        etManifestations = findViewById(R.id.et_manifestations);

        btnVerifier = findViewById(R.id.btn_verifier);
        btnAfficherCorrection = findViewById(R.id.btn_afficher_correction);
        tvResultat = findViewById(R.id.tv_resultat);
        tvCorrection = findViewById(R.id.tv_correction);
        layoutCorrection = findViewById(R.id.layout_correction);

        layoutCorrection.setVisibility(View.GONE);
    }

    private void setupListeners() {
        btnVerifier.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                verifierReponses();
            }
        });

        btnAfficherCorrection.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                afficherCorrection();
            }
        });
    }

    private void verifierReponses() {
        score = 0;
        StringBuilder feedback = new StringBuilder();

        String[] composantsCorrects = {"العنوان", "السلم", "المفتاح", "الاتجاهات"};
        String[] composantsSaisis = {
                etComposant1.getText().toString().trim(),
                etComposant2.getText().toString().trim(),
                etComposant3.getText().toString().trim(),
                etComposant4.getText().toString().trim()
        };

        int pointsComposants = 0;
        for (int i = 0; i < 4; i++) {
            if (composantsSaisis[i].toLowerCase().contains(composantsCorrects[i].toLowerCase()) ||
                    composantsSaisis[i].toLowerCase().contains(getTraductionFrancaise(i))) {
                pointsComposants++;
            }
        }
        score += pointsComposants;


        int surfaceTerrId = rgSurfaceTerre.getCheckedRadioButtonId();
        if (surfaceTerrId == R.id.rb_surface_terre_510) {
            score++;
        }

        int surfaceAlgerieId = rgSurfaceAlgerie.getCheckedRadioButtonId();
        if (surfaceAlgerieId == R.id.rb_surface_algerie_2381741) { // 2 381 741 km²
            score++;
        }

        int littoralId = rgLittoral.getCheckedRadioButtonId();
        if (littoralId == R.id.rb_littoral_1200) { // 1200 km
            score++;
        }

        int frontieresId = rgFrontieres.getCheckedRadioButtonId();
        if (frontieresId == R.id.rb_frontieres_libye) {
            score++;
        }

        if (cbCorrect1.isChecked()) score++;
        if (cbCorrect2.isChecked()) score++;
        if (!cbCorrect3.isChecked()) score++;
        if (cbCorrect4.isChecked()) score++;

        double pourcentage = (score * 100.0) / totalQuestions;
        String mention = getMention(pourcentage);

        tvResultat.setText(String.format("Score: %d/%d (%.1f%%) - %s",
                score, totalQuestions, pourcentage, mention));
        tvResultat.setVisibility(View.VISIBLE);

        Toast.makeText(this, String.format("Votre score: %d/%d", score, totalQuestions),
                Toast.LENGTH_LONG).show();
    }

    private String getTraductionFrancaise(int index) {
        String[] traductions = {"titre", "échelle", "légende", "orientation"};
        return traductions[index];
    }

    private String getMention(double pourcentage) {
        if (pourcentage >= 90) return "Excellent, Bravo héro !!";
        else if (pourcentage >= 80) return "Très Bien, continue comme ça !";
        else if (pourcentage >= 70) return "Bien, un bon effort !";
        else if (pourcentage >= 60) return "Assez Bien, vous pouvez faire plus ! ";
        else if (pourcentage >= 50) return "Passable, vous pouvez faire plus ! ";
        else return "Insuffisant, vous devez faire plus d'effort";
    }

    private void afficherCorrection() {
        StringBuilder correction = new StringBuilder();

        correction.append("CORRECTION COMPLÈTE:\n\n");

        correction.append("التمرين الأول - Exercice 1:\n");
        correction.append("مكونات الخريطة - Composants de la carte:\n");
        correction.append("1- العنوان (Le titre)\n");
        correction.append("2- السلم (L'échelle)\n");
        correction.append("3- المفتاح (La légende)\n");
        correction.append("4- الاتجاهات (L'orientation)\n\n");

        correction.append("التمرين الثاني - Exercice 2:\n");
        correction.append("- مساحة الأرض: 510 مليون كلم²\n");
        correction.append("- مساحة الجزائر: 2 381 741 كلم²\n");
        correction.append("- طول الشريط الساحلي: 1200 كلم\n");
        correction.append("- حدود مع: ليبيا\n\n");

        correction.append("التمرين الثالث - Exercice 3:\n");
        correction.append("1- صحيح ✓ - الجزائر الأولى إفريقياً والعاشرة عالمياً\n");
        correction.append("2- صحيح ✓ - الجزائر دولة متوسطية\n");
        correction.append("3- خاطئ ✗ - خط الاستواء يقسم إلى شمالي وجنوبي وليس شرقي وغربي\n");
        correction.append("4- صحيح ✓ - للأرض حركتان: حول نفسها وحول الشمس\n\n");

        correction.append("الوضعية الإدماجية - Situation d'intégration:\n");
        correction.append("مظاهر الانتماء الإفريقي للجزائر:\n");
        correction.append("- عضوية في الاتحاد الإفريقي\n");
        correction.append("- المشاركة في القمم الإفريقية\n");
        correction.append("- التعاون الاقتصادي مع الدول الإفريقية\n");
        correction.append("- الدعم للحركات التحررية الإفريقية\n");
        correction.append("- التبادل الثقافي والتعليمي\n");
        correction.append("- المساعدات التنموية للدول الإفريقية\n");

        tvCorrection.setText(correction.toString());
        layoutCorrection.setVisibility(View.VISIBLE);

        tvCorrection.post(new Runnable() {
            @Override
            public void run() {
                tvCorrection.requestFocus();
            }
        });
    }



    public String getConseils() {
        double pourcentage = (score * 100.0) / totalQuestions;

        if (pourcentage >= 80) {
            return "Excellent travail ! Continuez ainsi et approfondissez vos connaissances en géographie.";
        } else if (pourcentage >= 60) {
            return "Bon travail ! Révisez les points où vous avez eu des difficultés.";
        } else {
            return "Il faut revoir les leçons de géographie. Concentrez-vous sur la position de l'Algérie et ses caractéristiques.";
        }
    }
}