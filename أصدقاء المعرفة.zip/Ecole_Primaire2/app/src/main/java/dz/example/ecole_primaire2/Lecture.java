package dz.example.ecole_primaire2;

import android.os.Bundle;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;

public class Lecture extends AppCompatActivity {

    private TextView tvTitre, tvAuteur, tvCategorie;
    private ImageView ivCouverture;
    private Button btnPrecedent, btnSuivant;

    private String[] categories = {"دين", "ثقافة عامة", "كتب عن الجزائر"};
    private int currentCategoryIndex = 0;
    private int currentBookIndex = 0;


    private Book[][] books = {
            {
                    new Book("قصص الأنبياء للأطفال", "أحمد بهجت", R.drawable.religion_1),
                    new Book("تعليم الصلاة للأطفال", "محمد الصالح", R.drawable.religion_2),
                    new Book("سيرة النبي للأطفال", "ليلى حمد", R.drawable.religion_3)
            },

            {
                    new Book("موسوعة المعرفة للأطفال", "سمير قاسم", R.drawable.culture_1),
                    new Book("عجائب العالم", "فاطمة الزهراء", R.drawable.culture_2),
                    new Book("العلوم المبسطة", "عبد الكريم مختار", R.drawable.culture_3)
            },
            {
                    new Book("تاريخ الجزائر للناشئة", "مصطفى الأشرف", R.drawable.algerie_1),
                    new Book("ثورة الجزائر المجيدة", "أمينة بوزار", R.drawable.algerie_2),
                    new Book("معالم الجزائر", "كريم بلقاسم", R.drawable.algerie_3)
            }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.lecture);

        tvTitre = findViewById(R.id.tvTitre);
        tvAuteur = findViewById(R.id.tvAuteur);
        tvCategorie = findViewById(R.id.tvCategorie);
        ivCouverture = findViewById(R.id.ivCouverture);
        btnPrecedent = findViewById(R.id.btnPrecedent);
        btnSuivant = findViewById(R.id.btnSuivant);


        btnPrecedent.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                naviguerPrecedent();
            }
        });

        btnSuivant.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                naviguerSuivant();
            }
        });


        afficherLivreCourant();
    }


    private void naviguerPrecedent() {
        currentBookIndex--;
        if (currentBookIndex < 0) {
            currentCategoryIndex--;
            if (currentCategoryIndex < 0) {
                currentCategoryIndex = categories.length - 1;
            }
            currentBookIndex = books[currentCategoryIndex].length - 1;
        }
        afficherLivreCourant();
    }

    private void naviguerSuivant() {
        currentBookIndex++;
        if (currentBookIndex >= books[currentCategoryIndex].length) {
            currentBookIndex = 0;
            currentCategoryIndex = (currentCategoryIndex + 1) % categories.length;
        }
        afficherLivreCourant();
    }


    private void afficherLivreCourant() {
        Book currentBook = books[currentCategoryIndex][currentBookIndex];
        tvTitre.setText(currentBook.getTitre());
        tvAuteur.setText(currentBook.getAuteur());
        tvCategorie.setText(categories[currentCategoryIndex]);
        ivCouverture.setImageResource(currentBook.getImageResId());
    }

    private static class Book {
        private String titre;
        private String auteur;
        private int imageResId;

        public Book(String titre, String auteur, int imageResId) {
            this.titre = titre;
            this.auteur = auteur;
            this.imageResId = imageResId;
        }
        public String getTitre() {
            return titre;
        }
        public String getAuteur() {
            return auteur;
        }
        public int getImageResId() {
            return imageResId;
        }
    }
}