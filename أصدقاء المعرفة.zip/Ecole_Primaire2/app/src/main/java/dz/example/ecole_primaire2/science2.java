package dz.example.ecole_primaire2;

import android.app.Activity;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class science2 extends Activity {

    private EditText blank1, blank2, blank3, blank4;
    private Button checkAnswers1;

    private LinearLayout classificationLayout;
    private Button checkAnswers2;
    private List<TextView> classificationWords;
    private Map<TextView, String> wordCategories;

    private Button checkAnswers3;
    private Map<String, String> correctMatches;
    private Map<Button, Button> selectedMatches;
    private Button selectedOrgan = null;
    private List<Button> organButtons;
    private List<Button> functionButtons;

    private RadioGroup tfGroup1, tfGroup2, tfGroup3, tfGroup4;
    private Button checkTF;

    private RadioGroup mcqGroup1, mcqGroup2;
    private Button checkMCQ;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.science2);

        initializeViews();
        setupExercise1();
        setupExercise2();
        setupExercise3();
        setupExercise4();
        setupExercise5();
    }

    private void initializeViews() {
        blank1 = findViewById(R.id.blank1);
        blank2 = findViewById(R.id.blank2);
        blank3 = findViewById(R.id.blank3);
        blank4 = findViewById(R.id.blank4);
        checkAnswers1 = findViewById(R.id.check_answers1);

        classificationLayout = findViewById(R.id.classification_layout);
        checkAnswers2 = findViewById(R.id.check_answers2);

        checkAnswers3 = findViewById(R.id.check_answers3);

        tfGroup1 = findViewById(R.id.tf_group1);
        tfGroup2 = findViewById(R.id.tf_group2);
        tfGroup3 = findViewById(R.id.tf_group3);
        tfGroup4 = findViewById(R.id.tf_group4);
        checkTF = findViewById(R.id.check_tf);

        mcqGroup1 = findViewById(R.id.mcq_group1);
        mcqGroup2 = findViewById(R.id.mcq_group2);
        checkMCQ = findViewById(R.id.check_mcq);
    }

    private void setupExercise1() {
        checkAnswers1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                checkFillInTheBlanks();
            }
        });
    }

    private void checkFillInTheBlanks() {
        String[] correctAnswers = {"الأكسجين", "البناء الضوئي", "الكلوروفيل", "الجلوكوز"};
        EditText[] blanks = {blank1, blank2, blank3, blank4};

        int correctCount = 0;

        for (int i = 0; i < blanks.length; i++) {
            String userAnswer = blanks[i].getText().toString().trim();
            if (userAnswer.equals(correctAnswers[i])) {
                blanks[i].setBackgroundColor(Color.GREEN);
                correctCount++;
            } else {
                blanks[i].setBackgroundColor(Color.RED);
            }
        }

        String message = "النتيجة: " + correctCount + " من " + correctAnswers.length + " صحيحة";
        Toast.makeText(this, message, Toast.LENGTH_LONG).show();

        new android.os.Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                showCorrectAnswers();
            }
        }, 3000);
    }

    private void showCorrectAnswers() {
        String[] correctAnswers = {"الأكسجين", "البناء الضوئي", "الكلوروفيل", "الجلوكوز"};
        EditText[] blanks = {blank1, blank2, blank3, blank4};

        for (int i = 0; i < blanks.length; i++) {
            if (blanks[i].getText().toString().trim().isEmpty() ||
                    !blanks[i].getText().toString().trim().equals(correctAnswers[i])) {
                blanks[i].setText(correctAnswers[i]);
                blanks[i].setBackgroundColor(Color.YELLOW);
            }
        }
    }

    private void setupExercise2() {
        createClassificationWords();
        checkAnswers2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                checkClassification();
            }
        });
    }

    private void createClassificationWords() {
        String[] words = {"أسد", "وردة", "نخلة", "قطة", "صنوبر", "كلب", "زهرة عباد الشمس", "حصان"};
        String[] categories = {"حيوان", "نبات", "نبات", "حيوان", "نبات", "حيوان", "نبات", "حيوان"};

        classificationWords = new ArrayList<>();
        wordCategories = new HashMap<>();

        for (int i = 0; i < words.length; i++) {
            TextView wordView = new TextView(this);
            wordView.setText(words[i]);
            wordView.setTextSize(16);
            wordView.setPadding(16, 16, 16, 16);
            wordView.setBackgroundColor(Color.LTGRAY);
            wordView.setClickable(true);

            final String category = categories[i];
            wordView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    TextView tv = (TextView) v;
                    if (tv.getCurrentTextColor() == Color.BLUE) {
                        tv.setTextColor(Color.GREEN);
                        tv.setBackgroundColor(Color.parseColor("#E8F5E8"));
                    } else if (tv.getCurrentTextColor() == Color.GREEN) {
                        tv.setTextColor(Color.BLACK);
                        tv.setBackgroundColor(Color.LTGRAY);
                    } else {
                        tv.setTextColor(Color.BLUE);
                        tv.setBackgroundColor(Color.parseColor("#E8F0FF"));
                    }
                }
            });

            classificationWords.add(wordView);
            wordCategories.put(wordView, category);
            classificationLayout.addView(wordView);

            LinearLayout.LayoutParams params = (LinearLayout.LayoutParams) wordView.getLayoutParams();
            params.setMargins(8, 8, 8, 8);
            wordView.setLayoutParams(params);
        }
    }

    private void checkClassification() {
        int correctCount = 0;
        int totalWords = classificationWords.size();

        for (TextView wordView : classificationWords) {
            String expectedCategory = wordCategories.get(wordView);
            int textColor = wordView.getCurrentTextColor();

            boolean isCorrect = false;
            if (expectedCategory.equals("حيوان") && textColor == Color.BLUE) {
                isCorrect = true;
            } else if (expectedCategory.equals("نبات") && textColor == Color.GREEN) {
                isCorrect = true;
            }

            if (isCorrect) {
                correctCount++;
                wordView.setBackgroundColor(Color.parseColor("#90EE90")); // أخضر فاتح
            } else {
                wordView.setBackgroundColor(Color.parseColor("#FFB6C1")); // أحمر فاتح
            }
        }

        String message = "النتيجة: " + correctCount + " من " + totalWords + " صحيحة";
        Toast.makeText(this, message, Toast.LENGTH_LONG).show();
    }

    private void setupExercise3() {
        initializeMatchingExercise();
        checkAnswers3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                checkMatching();
            }
        });
    }

    private void initializeMatchingExercise() {
        correctMatches = new HashMap<>();
        correctMatches.put("القلب", "ضخ الدم");
        correctMatches.put("الرئتان", "التنفس");
        correctMatches.put("المعدة", "هضم الطعام");
        correctMatches.put("الكليتان", "تنقية الدم");

        selectedMatches = new HashMap<>();

        organButtons = Arrays.asList(
                findViewById(R.id.organ1),
                findViewById(R.id.organ2),
                findViewById(R.id.organ3),
                findViewById(R.id.organ4)
        );

        functionButtons = Arrays.asList(
                findViewById(R.id.function1),
                findViewById(R.id.function2),
                findViewById(R.id.function3),
                findViewById(R.id.function4)
        );

        for (Button organButton : organButtons) {
            organButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    selectOrgan((Button) v);
                }
            });
        }

        for (Button functionButton : functionButtons) {
            functionButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    selectFunction((Button) v);
                }
            });
        }
    }

    private void selectOrgan(Button organ) {
        if (selectedOrgan != null) {
            selectedOrgan.setBackgroundColor(Color.parseColor("#E0E0E0"));
        }

        selectedOrgan = organ;
        organ.setBackgroundColor(Color.parseColor("#FFE4B5"));
    }

    private void selectFunction(Button function) {
        if (selectedOrgan != null) {
            selectedMatches.put(selectedOrgan, function);

            selectedOrgan.setBackgroundColor(Color.parseColor("#98FB98"));
            function.setBackgroundColor(Color.parseColor("#98FB98"));

            selectedOrgan = null;
        }
    }

    private void checkMatching() {
        int correctCount = 0;
        int totalMatches = correctMatches.size();

        for (Map.Entry<Button, Button> entry : selectedMatches.entrySet()) {
            Button organButton = entry.getKey();
            Button functionButton = entry.getValue();

            String organ = organButton.getText().toString();
            String function = functionButton.getText().toString();

            if (correctMatches.containsKey(organ) && correctMatches.get(organ).equals(function)) {
                correctCount++;
                organButton.setBackgroundColor(Color.GREEN);
                functionButton.setBackgroundColor(Color.GREEN);
            } else {
                organButton.setBackgroundColor(Color.RED);
                functionButton.setBackgroundColor(Color.RED);
            }
        }

        String message = "النتيجة: " + correctCount + " من " + totalMatches + " مطابقة صحيحة";
        Toast.makeText(this, message, Toast.LENGTH_LONG).show();
    }

    private void setupExercise4() {
        checkTF.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                checkTrueFalse();
            }
        });
    }

    private void checkTrueFalse() {
        boolean[] correctAnswers = {false, false, true, false};
        RadioGroup[] groups = {tfGroup1, tfGroup2, tfGroup3, tfGroup4};

        int correctCount = 0;

        for (int i = 0; i < groups.length; i++) {
            int selectedId = groups[i].getCheckedRadioButtonId();
            if (selectedId != -1) {
                RadioButton selectedRadio = findViewById(selectedId);
                boolean userAnswer = selectedRadio.getText().toString().equals("صحيح");

                if (userAnswer == correctAnswers[i]) {
                    correctCount++;
                    selectedRadio.setTextColor(Color.GREEN);
                } else {
                    selectedRadio.setTextColor(Color.RED);
                }
            }
        }

        String message = "النتيجة: " + correctCount + " من " + correctAnswers.length + " إجابة صحيحة";
        Toast.makeText(this, message, Toast.LENGTH_LONG).show();
    }

    private void setupExercise5() {
        checkMCQ.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                checkMultipleChoice();
            }
        });
    }

    private void checkMultipleChoice() {
        String[] correctAnswers = {"ب) الأكسجين", "ج) 4"};
        RadioGroup[] groups = {mcqGroup1, mcqGroup2};

        int correctCount = 0;

        for (int i = 0; i < groups.length; i++) {
            int selectedId = groups[i].getCheckedRadioButtonId();
            if (selectedId != -1) {
                RadioButton selectedRadio = findViewById(selectedId);
                String userAnswer = selectedRadio.getText().toString();

                if (userAnswer.equals(correctAnswers[i])) {
                    correctCount++;
                    selectedRadio.setTextColor(Color.GREEN);
                } else {
                    selectedRadio.setTextColor(Color.RED);
                }
            }
        }

        String message = "النتيجة: " + correctCount + " من " + correctAnswers.length + " إجابة صحيحة";
        Toast.makeText(this, message, Toast.LENGTH_LONG).show();
    }

    public void resetAllExercises() {
        EditText[] blanks = {blank1, blank2, blank3, blank4};
        for (EditText blank : blanks) {
            blank.setText("");
            blank.setBackgroundColor(Color.WHITE);
        }

        for (TextView word : classificationWords) {
            word.setTextColor(Color.BLACK);
            word.setBackgroundColor(Color.LTGRAY);
        }

        selectedMatches.clear();
        selectedOrgan = null;
        for (Button button : organButtons) {
            button.setBackgroundColor(Color.parseColor("#E0E0E0"));
        }
        for (Button button : functionButtons) {
            button.setBackgroundColor(Color.parseColor("#E0E0E0"));
        }

        RadioGroup[] allGroups = {tfGroup1, tfGroup2, tfGroup3, tfGroup4, mcqGroup1, mcqGroup2};
        for (RadioGroup group : allGroups) {
            group.clearCheck();
            for (int i = 0; i < group.getChildCount(); i++) {
                if (group.getChildAt(i) instanceof RadioButton) {
                    ((RadioButton) group.getChildAt(i)).setTextColor(Color.BLACK);
                }
            }
        }
    }
}