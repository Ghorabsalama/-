package dz.example.ecole_primaire2;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class Matieres_5Ap extends AppCompatActivity {
    private CardView  arabicCard,  musicCard, conseilsCard;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_matieres5_ap);

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main_1), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
        ImageButton backButton = findViewById(R.id.backButton);
        backButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });

        arabicCard = findViewById(R.id.sportsCard);
        musicCard = findViewById(R.id.foodCard);
        conseilsCard = findViewById(R.id.conseilsCard);


        arabicCard.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Matieres_5Ap.this, arabic1.class);
                startActivity(intent);
            }
        });

        musicCard.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Matieres_5Ap.this, paragraph_api.class);
                startActivity(intent);
            }
        });


            conseilsCard.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {

                        Intent intent = new Intent(Matieres_5Ap.this, ConseilsActivity.class);
                        startActivity(intent);

                }
            });

    }
}