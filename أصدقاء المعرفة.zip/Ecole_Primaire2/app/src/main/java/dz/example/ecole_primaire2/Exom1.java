package dz.example.ecole_primaire2;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;


public class Exom1 extends AppCompatActivity {
    private EditText editTextText;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_exom1);

        editTextText = findViewById(R.id.editTextText);

        ImageButton backButton = findViewById(R.id.backButton);
        backButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });

        Button submitButton = findViewById(R.id.submitButton);
        submitButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                checkAnswer();
            }
        });
    }

    private void checkAnswer() {
        String answer = editTextText.getText().toString().trim();

        if (answer.equals("9")) {
            Intent intent = new Intent(Exom1.this, operations.class);
            startActivity(intent);
        } else {
            Toast.makeText(this, "أعد المحاولة", Toast.LENGTH_SHORT).show();
        }
    }
}