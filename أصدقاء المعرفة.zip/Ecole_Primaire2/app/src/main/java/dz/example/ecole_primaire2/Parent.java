package dz.example.ecole_primaire2;

import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.RecyclerView;
import com.google.android.material.textfield.TextInputEditText;
import java.util.ArrayList;
import java.util.List;

public class Parent extends AppCompatActivity {

    private TextView tvNomEleve;
    private TextView tvClasseEleve;
    private RecyclerView rvResultatsTests;
    private TextInputEditText etNomEnseignant;
    private TextInputEditText etMatiereEnseignant;
    private TextInputEditText etEmailEnseignant;
    private TextInputEditText etTelephoneEnseignant;
    private Button btnAjouterEnseignant;
    private Button btnModifierEnseignant;
    private RecyclerView rvEnseignants;
    private Eleve eleveConnecte;
    private List<Enseignant> listeEnseignants;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.parent);

        initialiserVues();
        initialiserDonnees();
        configurerEvenements();
        chargerDonneesEleve();
    }

    private void initialiserVues() {
        tvNomEleve = findViewById(R.id.tv_nom_eleve);
        tvClasseEleve = findViewById(R.id.tv_classe_eleve);
        rvResultatsTests = findViewById(R.id.rv_resultats_tests);
        etMatiereEnseignant = findViewById(R.id.et_matiere_enseignant);
        etEmailEnseignant = findViewById(R.id.et_email_enseignant);
        etTelephoneEnseignant = findViewById(R.id.et_telephone_enseignant);
        btnAjouterEnseignant = findViewById(R.id.btn_ajouter_enseignant);
        btnModifierEnseignant = findViewById(R.id.btn_modifier_enseignant);
        rvEnseignants = findViewById(R.id.rv_enseignants);
    }

    private void initialiserDonnees() {
        listeEnseignants = new ArrayList<>();
        eleveConnecte = new Eleve("Dupont", "Marie", "5ème A", "E001");
        ajouterEnseignantExemple();
    }



    private void ajouterEnseignantExemple() {
        listeEnseignants.add(new Enseignant("Mme Martin", "Mathématiques", "martin@ecole.fr", "01.23.45.67.89"));
        listeEnseignants.add(new Enseignant("M. Bernard", "Français", "bernard@ecole.fr", "01.23.45.67.90"));
    }



    private void configurerEvenements() {
        btnAjouterEnseignant.setOnClickListener(v -> ajouterEnseignant());
        btnModifierEnseignant.setOnClickListener(v -> modifierEnseignant());
    }

    private void chargerDonneesEleve() {
        if (eleveConnecte != null) {
            tvNomEleve.setText(eleveConnecte.getPrenom() + " " + eleveConnecte.getNom());
            tvClasseEleve.setText("Classe: " + eleveConnecte.getClasse());
        }
    }

    private void ajouterEnseignant() {
        String nom = etNomEnseignant.getText().toString().trim();
        String matiere = etMatiereEnseignant.getText().toString().trim();
        String email = etEmailEnseignant.getText().toString().trim();
        String telephone = etTelephoneEnseignant.getText().toString().trim();

        if (validerChampsEnseignant(nom, matiere, email)) {
            Enseignant nouvelEnseignant = new Enseignant(nom, matiere, email, telephone);
            listeEnseignants.add(nouvelEnseignant);
            Toast.makeText(this, "Enseignant ajouté avec succès", Toast.LENGTH_SHORT).show();
        }
    }

    private void modifierEnseignant() {
        Toast.makeText(this, "Sélectionnez un enseignant à modifier", Toast.LENGTH_SHORT).show();
    }

    private boolean validerChampsEnseignant(String nom, String matiere, String email) {
        if (nom.isEmpty()) {
            etNomEnseignant.setError("Le nom est requis");
            etNomEnseignant.requestFocus();
            return false;
        }
        if (matiere.isEmpty()) {
            etMatiereEnseignant.setError("La matière est requise");
            etMatiereEnseignant.requestFocus();
            return false;
        }
        if (email.isEmpty() || !android.util.Patterns.EMAIL_ADDRESS.matcher(email).matches()) {
            etEmailEnseignant.setError("Email valide requis");
            etEmailEnseignant.requestFocus();
            return false;
        }
        return true;
    }

    public static class Eleve {
        private String nom;
        private String prenom;
        private String classe;
        private String id;

        public Eleve(String nom, String prenom, String classe, String id) {
            this.nom = nom;
            this.prenom = prenom;
            this.classe = classe;
            this.id = id;
        }

        public String getNom() { return nom; }
        public String getPrenom() { return prenom; }
        public String getClasse() { return classe; }
        public String getId() { return id; }
    }

     public static class Enseignant {
            private String nom;
            private String matiere;
            private String email;
            private String telephone;

            public Enseignant(String nom, String matiere, String email, String telephone) {
                this.nom = nom;
                this.matiere = matiere;
                this.email = email;
                this.telephone = telephone;
            }

        }
    }
