package dz.example.ecole_primaire2;

public class Register {
}
